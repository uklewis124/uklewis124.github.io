import os
import sys
import json
import requests
import zipfile
import colorama
import tkinter as tk
from tkinter import filedialog
import ctypes
import subprocess
import time

def download():
    try:
        r = requests.get("https://lewisdavies.me/nihongo/current_request.json")
        r.raise_for_status()
        print(f"Downloading the latest version of Nihongo...")
        print(f"Latest Version: {r.json()['current_version']}")
        
        # Selecting a folder to download to
        root = tk.Tk()
        root.withdraw()

        save_path = filedialog.askdirectory()
        if not save_path:
            print("Download cancelled.")
            return
        
        URL = "https://lewisdavies.me/nihongo/latest.zip"
        destination = os.path.join(save_path, "latest.zip")
        
        def download_large_file(url, destination):
            try:
                with requests.get(url, stream=True) as response:
                    response.raise_for_status()
                    with open(destination, 'wb') as f:
                        for chunk in response.iter_content(chunk_size=8192):
                            f.write(chunk)
                
                with zipfile.ZipFile(destination, 'r') as zip_ref:
                    zip_ref.extractall(save_path)
                
                os.remove(destination)
                print("Download and extraction complete!")
                
                # Running the new version
                os.system(f"start {os.path.join(save_path, 'example.py')}")
            except requests.exceptions.RequestException as e:
                print("Error downloading the file:", e)
            except zipfile.BadZipFile as e:
                print("Error extracting the file:", e)
        
        download_large_file(URL, destination)

    except requests.exceptions.RequestException as e:
        print("Error retrieving the version info:", e)

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

if is_admin():
    download()
else:
    # Re-run the program with admin rights
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)

def install_packages():
    packages = ['requests', 'colorama']
    for package in packages:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package, '--quiet'])

try:
    import requests
    import colorama
except ImportError:
    install_packages()
    print("Please restart the script")
